#!usr/bin/bash
out_dir=webms/
if [ -d $out_dir ]; then
	sudo rm -r $out_dir
fi
sudo mkdir $out_dir

for avi in *.avi
do
	name=${avi%.*}
	yes | ffmpeg -i $avi -b:v 1600K -c:a libvorbis -b:a 192K -c:v libvpx-vp9 -crf 18  $name.webm
done
if [ -d webms/ ]; then
	sudo rm -r webms/
fi
sudo mkdir webms
sudo cp *.webm webms/
sudo rm -r *.webm
echo "Done!"


