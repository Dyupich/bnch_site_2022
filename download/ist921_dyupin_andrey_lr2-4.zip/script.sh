#!/usr/bin/bash
txt="дюпин андрей алексеевич 27.01.2001 Екатеринбург Гимназия 174"
path1="$HOME"
cd $path1
tmp_dir="lab1"

if [ -d $tmp_dir ]; then
    rm -r $tmp_dir
fi

mkdir $tmp_dir
cd $tmp_dir

echo $txt > 3.txt
iconv -f UTF-8 -t cp866 < 3.txt > 1.txt
iconv -f UTF-8 -t WINDOWS-1251 < 3.txt > 2.txt
iconv -f UTF-8 -t 8859_5 < 3.txt > 4.txt

cat *.txt > result.txt

arj a 1.txt.arj 1.txt
jar -cvf 2.txt.jar 2.txt
bzip2 -k --best 3.txt
rar a 4.txt.rar 4.txt
zip -9 result.txt.zip result.txt

ls -l
cd ..
tar -cvJSf "$tmp_dir.tar.bz2" $tmp_dir
rm -r $tmp_dir
echo "----->Done!<-----"
