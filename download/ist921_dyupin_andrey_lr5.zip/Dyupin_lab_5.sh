#!/usr/bin/sh
txt="Дюпин Андрей Алексеевич 27.01.2001 Екатеринбург Гимназия 174 Dyupin Andrey Alekceevich 27.01.2001 Ekaterinburg 174"
path="$HOME"
cd $path
dir="lab5"
if [ -d $dir ]; then
	rm -r $dir
fi

mkdir $dir
cd $dir
touch text.txt
for i in {1..100}
do
	echo "$txt" >> text.txt 
done

for i in {1..25}
do
	echo $txt | tr абвгдеёжзийклмнопрстуфцчшщъыьэюя№ АБВГДЕЁЖЗИЙКЛМНОПРСТУФЦЧШЩЪЫЬЭЮЯ№ >> text.txt
done

cat text.txt | sed "y/_ABEKMHOPCTYXaeopcy/ АВЕКМНОРСТУХАЕОРСУ/" > 3.txt
rm text.txt
iconv -f UTF-8 -t cp866 < 3.txt > 1.txt
iconv -f UTF-8 -t WINDOWS-1251 < 3.txt > 2.txt
iconv -f UTF-8 -t 8859_5 < 3.txt > 4.txt

cat *.txt > result.txt

for i in *.txt
do
    arj a $i.arj $i
    jar -cvf $i.jar $i
    bzip2 -k --best $i
    rar a $i.rar $i
    zip -9 $i.zip $i
done
ls -l
cd ..
tar -cvJSf "AIS_IST921_Dyupin_LR5.tar.bz2" $dir
rm -r $dir
echo "Done"
